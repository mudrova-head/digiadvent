import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="fixed bottom-0 left-0 w-full bg-cyber-dark/95 border-t border-cyber-green/30 backdrop-blur-md p-4 text-center z-40">
      <p className="text-gray-300 text-sm md:text-base font-medium">
        <span className="text-cyber-green mr-2">➜</span>
        "Programování je magie: Tvoříš budoucnost řádek po řádku." 
        <span className="block sm:inline sm:ml-2 text-xs text-gray-500 italic">
          (Jen bacha na nekonečné smyčky, ať stihneš Štědrý večer!)
        </span>
      </p>
    </footer>
  );
};

export default Footer;