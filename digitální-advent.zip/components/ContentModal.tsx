import React, { useEffect, useState } from 'react';
import { generateDailyText, generateDailyImage, evaluateAnswer } from '../services/geminiService';
import { DailyContent, DifficultyLevel, AnswerStatus } from '../types';

interface ContentModalProps {
  day: number;
  onClose: () => void;
  onComplete: (status: AnswerStatus) => void;
}

const ContentModal: React.FC<ContentModalProps> = ({ day, onClose, onComplete }) => {
  const [selectedDifficulty, setSelectedDifficulty] = useState<DifficultyLevel | null>(null);
  const [content, setContent] = useState<DailyContent | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loadingText, setLoadingText] = useState(false);
  const [loadingImage, setLoadingImage] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Phase 2 state: Evaluation
  const [isAnswerRevealed, setIsAnswerRevealed] = useState(false);
  const [userAnswer, setUserAnswer] = useState('');
  const [isValidating, setIsValidating] = useState(false);
  const [evaluationResult, setEvaluationResult] = useState<{isCorrect: boolean, feedback: string} | null>(null);

  useEffect(() => {
    if (!selectedDifficulty) return; 

    let isMounted = true;

    const fetchData = async () => {
      try {
        setLoadingText(true);
        const textData = await generateDailyText(day, selectedDifficulty);
        
        if (isMounted) {
          setContent(textData);
          setLoadingText(false);
          setLoadingImage(true);
        }

        const imgRes = await generateDailyImage(textData.imagePrompt);
        
        if (isMounted) {
          setImageUrl(imgRes.imageUrl);
          setLoadingImage(false);
        }
      } catch (err) {
        if (isMounted) {
          setError("Chyba při komunikaci s AI serverem.");
          setLoadingText(false);
          setLoadingImage(false);
        }
      }
    };

    fetchData();

    return () => {
      isMounted = false;
    };
  }, [day, selectedDifficulty]);

  const handleDifficultySelect = (level: DifficultyLevel) => {
    setSelectedDifficulty(level);
  };

  const handleSubmitAnswer = async () => {
    if (!content || !userAnswer.trim()) return;

    setIsValidating(true);
    try {
      // Call AI to evaluate
      const result = await evaluateAnswer(content.question, content.fact, userAnswer);
      
      setEvaluationResult(result);
      setIsAnswerRevealed(true);
      
      // Trigger completion logic in App
      onComplete(result.isCorrect ? 'CORRECT' : 'INCORRECT');
      
    } catch (e) {
      console.error(e);
      setError("Nepodařilo se ověřit odpověď.");
    } finally {
      setIsValidating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>
      
      <div className="relative bg-[#0f0f0f] border border-cyber-green/40 w-full max-w-2xl rounded-2xl shadow-[0_0_50px_rgba(0,255,65,0.15)] overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-gray-900 to-black p-4 flex justify-between items-center border-b border-gray-800">
          <h2 className="text-xl md:text-2xl font-bold text-cyber-green font-mono">
            Den {day} <span className="text-white text-base font-normal opacity-50">/ 24</span>
          </h2>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {error && (
             <div className="text-red-400 bg-red-900/10 p-4 rounded border border-red-500/20">
               {error}
             </div>
          )}

          {/* STATE 1: Difficulty Selection */}
          {!selectedDifficulty && !error && (
            <div className="flex flex-col items-center justify-center min-h-[300px] text-center space-y-8 animate-fadeIn">
              <h3 className="text-2xl font-bold text-white mb-2">Vyber si obtížnost úkolu</h3>
              <p className="text-gray-400 text-sm max-w-md">
                Zvol si level, na který se dnes cítíš. Vygenerujeme otázku dle tvého výběru.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full">
                <button
                  onClick={() => handleDifficultySelect('EASY')}
                  className="bg-green-900/20 border border-green-500/30 hover:bg-green-500/20 p-6 rounded-xl transition-all hover:scale-105 group"
                >
                  <div className="text-3xl mb-2 group-hover:animate-bounce">👶</div>
                  <div className="font-bold text-green-400 mb-1">ZAČÁTEČNÍK</div>
                  <div className="text-xs text-gray-400">Pro 1.-5. třídu</div>
                </button>

                <button
                  onClick={() => handleDifficultySelect('MEDIUM')}
                  className="bg-blue-900/20 border border-blue-500/30 hover:bg-blue-500/20 p-6 rounded-xl transition-all hover:scale-105 group"
                >
                   <div className="text-3xl mb-2 group-hover:animate-bounce">🎓</div>
                   <div className="font-bold text-blue-400 mb-1">POKROČILÝ</div>
                   <div className="text-xs text-gray-400">Pro 6.-7. třídu</div>
                </button>

                <button
                  onClick={() => handleDifficultySelect('HARD')}
                  className="bg-red-900/20 border border-red-500/30 hover:bg-red-500/20 p-6 rounded-xl transition-all hover:scale-105 group"
                >
                   <div className="text-3xl mb-2 group-hover:animate-bounce">💻</div>
                   <div className="font-bold text-red-400 mb-1">HACKER</div>
                   <div className="text-xs text-gray-400">Pro 8.-9. třídu</div>
                </button>
              </div>
            </div>
          )}

          {/* STATE 2: Loading Text */}
          {selectedDifficulty && loadingText && (
            <div className="flex flex-col items-center justify-center py-12 space-y-4">
              <div className="w-12 h-12 border-4 border-cyber-green border-t-transparent rounded-full animate-spin"></div>
              <p className="text-cyber-green animate-pulse font-mono">
                Generuji úkol (úroveň: {selectedDifficulty === 'EASY' ? 'ZAČÁTEČNÍK' : selectedDifficulty === 'MEDIUM' ? 'POKROČILÝ' : 'HACKER'})...
              </p>
            </div>
          )}

          {/* STATE 3: Content Display */}
          {content && !loadingText && (
            <>
              {/* Title & Topic */}
              <div className="text-center">
                 <div className="flex justify-center gap-2 mb-2">
                   <span className="inline-block px-3 py-1 rounded-full bg-cyber-green/10 text-cyber-green text-xs font-bold tracking-wider border border-cyber-green/20">
                     {content.topic.toUpperCase()}
                   </span>
                   {selectedDifficulty === 'HARD' && (
                     <span className="inline-block px-3 py-1 rounded-full bg-red-900/30 text-red-500 text-xs font-bold tracking-wider border border-red-500/30">
                       HACKER MODE
                     </span>
                   )}
                 </div>
                 <h3 className="text-2xl font-bold text-white mb-4">{content.topic}</h3>
              </div>

              {/* Image Section */}
              <div className="aspect-video w-full bg-black/40 rounded-xl overflow-hidden border border-gray-800 flex items-center justify-center relative group">
                {loadingImage ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/50">
                    <div className="w-8 h-8 border-2 border-blue-400 border-b-transparent rounded-full animate-spin mb-2"></div>
                    <span className="text-xs text-blue-300">Generování vizuálu...</span>
                  </div>
                ) : imageUrl ? (
                   <img src={imageUrl} alt={content.topic} className="w-full h-full object-cover transition-transform duration-700 hover:scale-105" />
                ) : (
                  <div className="text-gray-600 italic">Obrázek se nepodařilo načíst.</div>
                )}
              </div>

              {/* QUESTION Section (Main Task) */}
              <div className="bg-cyber-dark/80 p-6 rounded-xl border border-cyber-green/50 shadow-[0_0_15px_rgba(0,255,65,0.1)]">
                <h4 className="text-cyber-green font-bold mb-3 flex items-center text-lg font-mono">
                  <span className="mr-2">?</span> ÚKOL DNE:
                </h4>
                <p className="text-white text-lg font-medium leading-relaxed mb-4">
                  {content.question}
                </p>

                {/* Answer Input Area */}
                <div className="relative">
                  <textarea 
                    value={userAnswer}
                    onChange={(e) => setUserAnswer(e.target.value)}
                    placeholder="Sem napiš svou odpověď..."
                    readOnly={isAnswerRevealed || isValidating}
                    className={`
                      w-full bg-black/60 border rounded-lg p-3 text-white font-mono text-sm focus:outline-none focus:ring-1 transition-all
                      ${isAnswerRevealed 
                         ? evaluationResult?.isCorrect ? 'border-red-500/50 text-red-300' : 'border-blue-500/50 text-blue-300'
                         : 'border-cyber-green/30 focus:border-cyber-green focus:ring-cyber-green'
                      }
                    `}
                    rows={3}
                  />
                </div>

                {/* Submit Action */}
                {!isAnswerRevealed && (
                  <button
                    onClick={handleSubmitAnswer}
                    disabled={!userAnswer.trim() || isValidating}
                    className={`
                      w-full mt-4 font-bold py-3 px-4 rounded-lg transition-all font-mono tracking-wide flex items-center justify-center gap-2
                      ${!userAnswer.trim() || isValidating 
                        ? 'bg-gray-800 text-gray-500 cursor-not-allowed' 
                        : 'bg-cyber-green text-black hover:bg-green-400 shadow-[0_0_10px_rgba(0,255,65,0.3)]'
                      }
                    `}
                  >
                    {isValidating ? (
                      <>
                        <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                        OVĚŘUJI...
                      </>
                    ) : (
                      <>
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                           <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        OVĚŘIT ODPOVĚĎ
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* REVEALED CONTENT: Result, Fact & Joke */}
              {isAnswerRevealed && evaluationResult && (
                <div className="animate-slideIn space-y-6">
                  
                  {/* Result Banner */}
                  <div className={`p-4 rounded-xl border flex items-center gap-4 ${evaluationResult.isCorrect ? 'bg-red-900/30 border-red-500' : 'bg-blue-900/30 border-blue-500'}`}>
                     <div className={`text-3xl ${evaluationResult.isCorrect ? 'text-red-500' : 'text-blue-500'}`}>
                       {evaluationResult.isCorrect ? '★' : '⚠'}
                     </div>
                     <div>
                       <h4 className={`font-bold ${evaluationResult.isCorrect ? 'text-red-400' : 'text-blue-400'}`}>
                         {evaluationResult.isCorrect ? 'SPRÁVNĚ!' : 'BOHUŽEL...'}
                       </h4>
                       <p className="text-gray-300 text-sm">{evaluationResult.feedback}</p>
                     </div>
                  </div>

                  {/* Fact/Explanation */}
                  <div className="bg-gray-900/50 p-5 rounded-xl border-l-4 border-blue-500 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-2 opacity-20 text-blue-500">
                      <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <h4 className="text-blue-400 font-bold mb-2 flex items-center text-sm uppercase tracking-wide relative z-10">
                      Vysvětlení
                    </h4>
                    <p className="text-gray-200 leading-relaxed relative z-10">{content.fact}</p>
                  </div>

                  {/* Joke */}
                  <div className="bg-gray-900/50 p-5 rounded-xl border-l-4 border-yellow-500">
                     <h4 className="text-yellow-500 font-bold mb-2 flex items-center text-sm uppercase tracking-wide">
                      Bonus
                    </h4>
                    <p className="text-gray-300 italic font-mono text-sm">{content.joke}</p>
                  </div>
                  
                  {/* Close Instructions */}
                  <div className="text-center pt-4">
                    <button onClick={onClose} className="text-gray-400 hover:text-white underline text-sm">
                      Zavřít a vrátit se do kalendáře
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default ContentModal;