import React, { useState } from 'react';
import { User, UserRole } from '../types';

interface LoginFormProps {
  onLogin: (user: User) => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [isTeacher, setIsTeacher] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) {
      setError('Jméno a email jsou povinné údaje.');
      return;
    }
    onLogin({
      name,
      email,
      role: isTeacher ? UserRole.TEACHER : UserRole.STUDENT,
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-cyber-dark relative overflow-hidden px-4">
      {/* Christmas Digi World Background */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        {/* Technical Grid */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,65,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,65,0.05)_1px,transparent_1px)] bg-[size:50px_50px] [mask-image:radial-gradient(ellipse_80%_80%_at_50%_50%,black_40%,transparent_100%)]"></div>
        
        {/* Festive Glows */}
        <div className="absolute top-[-10%] left-[20%] w-[500px] h-[500px] bg-cyber-green/10 rounded-full blur-[100px] animate-pulse-slow"></div>
        <div className="absolute bottom-[-10%] right-[20%] w-[500px] h-[500px] bg-cyber-red/10 rounded-full blur-[100px] animate-pulse-slow delay-1000"></div>
        <div className="absolute top-[40%] left-[50%] transform -translate-x-1/2 w-[300px] h-[300px] bg-holiday-gold/5 rounded-full blur-[80px]"></div>
        
        {/* Binary Rain Effect (Static decoration) */}
        <div className="absolute top-10 left-10 text-cyber-green/20 font-mono text-sm hidden md:block select-none">
          01001000 01001111 01001000 01001111 00001010
        </div>
        <div className="absolute bottom-10 right-10 text-cyber-red/20 font-mono text-sm hidden md:block select-none">
          01011000 01001101 01000001 01010011 00001010
        </div>
      </div>
      
      <div className="relative z-10 w-full max-w-md p-8 glass-panel rounded-2xl shadow-[0_0_40px_rgba(0,255,65,0.1)] border border-cyber-green/30 backdrop-blur-xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyber-green via-white to-cyber-green font-mono mb-2 tracking-tight">
            Digitální advent
          </h1>
          <p className="text-gray-400 text-sm font-mono border-t border-gray-700/50 pt-2 inline-block">
            System.init(Christmas_v25.0)
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-cyber-green mb-1 font-mono">
              &lt;Jméno /&gt; <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-black/60 border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-green focus:ring-1 focus:ring-cyber-green transition-all placeholder-gray-600 font-mono"
              placeholder="Jan Novák"
            />
          </div>

          <div>
            <label htmlFor="email" className="block text-sm font-medium text-cyber-green mb-1 font-mono">
              &lt;Email /&gt; <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-black/60 border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-green focus:ring-1 focus:ring-cyber-green transition-all placeholder-gray-600 font-mono"
              placeholder="jan@skola.cz"
            />
          </div>

          <div className="flex items-center bg-gray-900/40 p-3 rounded-lg border border-gray-800">
            <input
              type="checkbox"
              id="teacher"
              checked={isTeacher}
              onChange={(e) => setIsTeacher(e.target.checked)}
              className="w-4 h-4 text-cyber-green bg-gray-900 border-gray-700 rounded focus:ring-cyber-green focus:ring-2 cursor-pointer"
            />
            <label htmlFor="teacher" className="ml-2 text-sm text-gray-300 cursor-pointer select-none">
              Přihlásit jako učitel
            </label>
          </div>

          {error && (
            <div className="text-red-400 text-sm bg-red-900/10 p-3 rounded border border-red-500/30 flex items-center">
              <span className="mr-2">⚠️</span> {error}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-cyber-green text-black font-bold py-3 px-4 rounded-lg hover:bg-green-400 hover:shadow-[0_0_20px_rgba(0,255,65,0.6)] transition-all duration-300 transform hover:-translate-y-1 font-mono tracking-widest border border-transparent hover:border-white"
          >
            VSTUP DO MATRIXU
          </button>

          <p className="text-center text-xs text-gray-400 font-mono mt-4 leading-relaxed opacity-80">
            "Programování je magie: Tvoříš budoucnost řádek po řádku."
            <span className="block mt-1 text-gray-500 italic text-[10px]">
              (Jen bacha na nekonečné smyčky, ať stihneš Štědrý večer!)
            </span>
          </p>
        </form>
      </div>
    </div>
  );
};

export default LoginForm;