import React, { useState, useEffect } from 'react';
import LoginForm from './components/LoginForm';
import Footer from './components/Footer';
import ContentModal from './components/ContentModal';
import { User, UserRole, AnswerStatus } from './types';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  // Store status map: { [day]: 'CORRECT' | 'INCORRECT' }
  const [dayStatuses, setDayStatuses] = useState<Record<number, AnswerStatus>>({});
  
  // --- TEST MODE CONFIGURATION ---
  const currentDay = 25;
  const isDecember = true;

  /* 
  // --- PRODUCTION MODE (REAL DATE) ---
  const today = new Date();
  const currentDay = today.getDate();
  const currentMonth = today.getMonth() + 1; // 1-12
  const isDecember = currentMonth === 12;
  */

  // Load progress when user changes
  useEffect(() => {
    if (user) {
      // Load new status format
      const savedStatus = localStorage.getItem(`digit_advent_status_v2_${user.email}`);
      if (savedStatus) {
        setDayStatuses(JSON.parse(savedStatus));
      } else {
        // Fallback for migration: check old array format if exists
        const oldProgress = localStorage.getItem(`digit_advent_progress_${user.email}`);
        if (oldProgress) {
          const oldDays: number[] = JSON.parse(oldProgress);
          const migrated: Record<number, AnswerStatus> = {};
          oldDays.forEach(d => { migrated[d] = 'CORRECT'; }); // Default old ones to correct
          setDayStatuses(migrated);
        } else {
          setDayStatuses({});
        }
      }
    }
  }, [user]);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
  };

  const handleDoorClick = (day: number) => {
    if (!user) return;

    const isTeacher = user.role === UserRole.TEACHER;
    
    // 1. Check Date
    const isDateValid = isTeacher || (isDecember && day <= currentDay);
    
    // 2. Check Sequence (Previous day must be completed, unless it's Day 1)
    const previousDay = day - 1;
    const isPreviousCompleted = day === 1 || !!dayStatuses[previousDay] || isTeacher;

    if (!isDateValid) {
      alert("Tento den ještě nenastal! Žádné předbíhání, ani pomocí SQL Injection! 🎅🚫");
      return;
    }

    if (!isPreviousCompleted) {
      alert(`Nemůžeš otevřít den ${day}, dokud nevyřešíš den ${day - 1}! Postupuj pěkně popořadě. 🔒`);
      return;
    }

    // Allow re-opening completed days to see content, but status won't change
    setSelectedDay(day);
  };

  const handleDayComplete = (status: AnswerStatus) => {
    if (selectedDay !== null && user) {
      const newStatuses = { ...dayStatuses, [selectedDay]: status };
      setDayStatuses(newStatuses);
      localStorage.setItem(`digit_advent_status_v2_${user.email}`, JSON.stringify(newStatuses));
      // Don't close immediately so user can read explanation
    }
  };

  const handleCloseModal = () => {
    setSelectedDay(null);
  };

  // Generate 24 days
  const days = Array.from({ length: 24 }, (_, i) => i + 1);

  if (!user) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-cyber-dark text-white pb-20 relative">
      {/* Background Effect for Main App */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:60px_60px]"></div>
        <div className="absolute top-0 right-0 w-[50vw] h-[50vw] bg-cyber-green/5 rounded-full blur-[150px]"></div>
        <div className="absolute bottom-0 left-0 w-[50vw] h-[50vw] bg-cyber-red/5 rounded-full blur-[150px]"></div>
      </div>

      {/* Header */}
      <header className="p-6 flex justify-between items-center border-b border-gray-800 bg-black/80 backdrop-blur-md sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <div className="bg-cyber-green/10 p-2 rounded-lg border border-cyber-green/30 shadow-[0_0_10px_rgba(0,255,65,0.2)]">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-cyber-green" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
             </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold font-mono tracking-tight text-white">Digitální advent</h1>
            <p className="text-xs text-gray-400 flex items-center">
              User: <span className="text-cyber-green ml-1">{user.name}</span>
              {user.role === UserRole.TEACHER && (
                <span className="ml-2 text-[10px] bg-red-900/50 text-red-400 border border-red-800 px-1 rounded uppercase">Admin</span>
              )}
            </p>
          </div>
        </div>
        <button 
          onClick={() => setUser(null)}
          className="text-sm text-gray-400 hover:text-white border border-gray-700 px-4 py-2 rounded hover:bg-gray-800 transition font-mono hover:border-cyber-red/50"
        >
          Odhlásit
        </button>
      </header>

      {/* Grid */}
      <main className="container mx-auto px-4 py-8 relative z-10">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4 md:gap-6">
          {days.map((day) => {
            const isTeacher = user.role === UserRole.TEACHER;
            const isDateValid = isTeacher || (isDecember && day <= currentDay);
            const status = dayStatuses[day]; // 'CORRECT' | 'INCORRECT' | undefined
            const isCompleted = !!status;
            
            const previousDay = day - 1;
            const isPreviousCompleted = day === 1 || !!dayStatuses[previousDay] || isTeacher;
            
            const isUnlocked = isDateValid && isPreviousCompleted;
            const isNextToOpen = isUnlocked && !isCompleted;

            // Determine Background Color based on requirements:
            // Correct -> Red
            // Incorrect -> Blue
            // Default Completed (Legacy) -> Greenish (fallback)
            let bgClass = 'bg-gray-800/40 border-gray-700 opacity-50 grayscale'; // Locked
            let shadowClass = '';
            let textClass = 'text-gray-600';

            if (status === 'CORRECT') {
              bgClass = 'bg-red-600/20 border-red-500 shadow-[0_0_15px_rgba(220,38,38,0.4)]';
              textClass = 'text-red-500';
            } else if (status === 'INCORRECT') {
              bgClass = 'bg-blue-600/20 border-blue-500 shadow-[0_0_15px_rgba(37,99,235,0.4)]';
              textClass = 'text-blue-500';
            } else if (isNextToOpen) {
              bgClass = 'bg-gray-900 border-white/40 animate-pulse-slow shadow-[0_0_20px_rgba(255,255,255,0.1)]';
              textClass = 'text-white';
            } else if (isUnlocked && !isCompleted) {
               // Future days that are technically unlocked by date/sequence but not next (shouldnt happen often in sequential)
               bgClass = 'bg-gray-800 border-gray-600';
               textClass = 'text-gray-400';
            }

            return (
              <div
                key={day}
                onClick={() => handleDoorClick(day)}
                className={`
                  aspect-square relative group perspective-1000
                  transition-all duration-300 transform
                  ${isUnlocked ? 'cursor-pointer hover:-translate-y-1' : 'cursor-not-allowed'}
                `}
              >
                {/* Card Container */}
                <div className={`
                  w-full h-full rounded-xl border flex flex-col items-center justify-center
                  shadow-lg transition-all duration-500 overflow-hidden relative
                  ${bgClass}
                `}>
                  
                  {/* Background decoration */}
                  <div className="absolute inset-0 opacity-10 pointer-events-none overflow-hidden">
                    <div className="text-[10px] leading-3 font-mono text-white break-words w-full h-full opacity-50">
                      {Array.from({length: 100}).map(() => Math.random() > 0.5 ? '1' : '0').join(' ')}
                    </div>
                  </div>

                  {/* Day Number */}
                  <span className={`
                    text-4xl md:text-5xl font-bold font-mono z-10 drop-shadow-lg
                    ${textClass}
                  `}>
                    {day}
                  </span>

                  {/* Icon/Status */}
                  <div className="mt-2 z-10">
                    {status === 'CORRECT' ? (
                       <div className="flex items-center gap-1 text-red-500 bg-black/50 px-2 py-1 rounded border border-red-500/30">
                          <span className="text-xl">★</span>
                          <span className="text-[10px] font-bold">SPRÁVNĚ</span>
                       </div>
                    ) : status === 'INCORRECT' ? (
                        <div className="flex items-center gap-1 text-blue-500 bg-black/50 px-2 py-1 rounded border border-blue-500/30">
                          <span className="text-xl">⚠</span>
                          <span className="text-[10px] font-bold">CHYBA</span>
                       </div>
                    ) : isUnlocked ? (
                       <span className="text-holiday-gold text-[10px] font-bold animate-pulse border border-holiday-gold px-2 py-0.5 rounded bg-holiday-gold/10">
                         OTEVŘÍT
                       </span>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                      </svg>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      <Footer />

      {selectedDay && (
        <ContentModal 
          day={selectedDay} 
          onClose={handleCloseModal}
          onComplete={handleDayComplete}
        />
      )}
    </div>
  );
};

export default App;