import { GoogleGenAI, Type } from "@google/genai";
import { DailyContent, GeneratedImageResponse, DifficultyLevel, EvaluationResponse } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment variables");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateDailyText = async (day: number, difficulty: DifficultyLevel): Promise<DailyContent> => {
  const ai = getClient();
  
  let difficultyInstruction = "";
  switch (difficulty) {
    case 'EASY':
      difficultyInstruction = "ÚROVEŇ OBTÍŽNOSTI: LEHKÁ. Cílová skupina: 1.-5. třída ZŠ. Otázka musí být velmi jednoduchá, zaměřená na úplné základy (co je myš, klávesnice, monitor).";
      break;
    case 'MEDIUM':
      difficultyInstruction = "ÚROVEŇ OBTÍŽNOSTI: STŘEDNÍ. Cílová skupina: 6.-7. třída ZŠ. Standardní informatiska, běžné pojmy (hardware, software, internet, bezpečnost).";
      break;
    case 'HARD':
      difficultyInstruction = "ÚROVEŇ OBTÍŽNOSTI: TĚŽKÁ (Hacker). Cílová skupina: 8.-9. třída ZŠ (2. stupeň). Otázka musí být výzvou, ale STRIKTNĚ v rámci znalostí žáka základní školy. Témata: Binární soustava, logické myšlení, základy sítí (IP, doména), bezpečnost hesel, jednoduché algoritmy. NEPOUŽÍVEJ vysokoškolskou látku ani složité programovací jazyky.";
      break;
  }

  const prompt = `
    Jsi kreativní učitel informatiky pro projekt "Digitální advent" určený pro žáky Základní školy (ZŠ). Vytvoř obsah pro den číslo ${day} (z 24).
    
    POŽADAVKY:
    1. Téma musí být průnikem Vánoc a Informatiky.
    2. ${difficultyInstruction}
    
    Vygeneruj JSON s těmito poli:
    - topic: Krátký název tématu (např. "Binární Vánoce", "Bezpečné heslo pro Santu").
    - question: Otázka nebo úkol z informatiky odpovídající zvolené obtížnosti.
    - fact: Stručné vysvětlení správné odpovědi nebo zajímavost k tématu (2-3 věty). Začni přímou odpovědí na otázku.
    - joke: Krátký vtip nebo "nerdy" poznámka.
    - imagePrompt: Velmi detailní prompt v angličtině pro generování obrázku.
      DŮLEŽITÉ PRO OBRÁZEK: Musí to být "Christmas Digi World".
      Musí obsahovat vizuální fúzi:
      - Vánoční prvky: Sníh, stromeček, Santa, dárky, sob, ozdoby.
      - IT prvky: Tištěné spoje, binární kód, hologramy, robotická ramena, monitory, kabely.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            day: { type: Type.INTEGER },
            topic: { type: Type.STRING },
            question: { type: Type.STRING },
            fact: { type: Type.STRING },
            joke: { type: Type.STRING },
            imagePrompt: { type: Type.STRING },
          },
          required: ["topic", "question", "fact", "joke", "imagePrompt"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No text returned from Gemini");
    
    const data = JSON.parse(text);
    return { ...data, day };

  } catch (error) {
    console.error("Error generating text:", error);
    throw error;
  }
};

export const generateDailyImage = async (prompt: string): Promise<GeneratedImageResponse> => {
  const ai = getClient();

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { text: prompt }
        ]
      },
      config: {
       // No specific image config needed for basic generation
      }
    });

    let imageUrl: string | null = null;
    
    const candidates = response.candidates;
    if (candidates && candidates.length > 0) {
       for (const part of candidates[0].content.parts) {
         if (part.inlineData && part.inlineData.mimeType.startsWith('image/')) {
            imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            break;
         }
       }
    }

    if (!imageUrl) {
        throw new Error("No image data found in response");
    }

    return { imageUrl };

  } catch (error) {
    console.error("Error generating image:", error);
    return { imageUrl: null, error: "Nepodařilo se vygenerovat obrázek." };
  }
};

export const evaluateAnswer = async (question: string, correctFact: string, userAnswer: string): Promise<EvaluationResponse> => {
  const ai = getClient();
  
  const prompt = `
    Jsi učitel informatiky. Porovnej odpověď žáka se správným řešením.
    
    Otázka: "${question}"
    Správný kontext/fakt: "${correctFact}"
    Odpověď žáka: "${userAnswer}"
    
    Rozhodni, zda je odpověď žáka SPRÁVNĚ (stačí významově, nemusí být slovo od slova) nebo ŠPATNĚ.
    
    Vrať JSON:
    {
      "isCorrect": boolean,
      "feedback": "Krátká věta pro žáka (např. 'Super, to je ono!' nebo 'Bohužel, správně je to trochu jinak...')"
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isCorrect: { type: Type.BOOLEAN },
            feedback: { type: Type.STRING },
          },
          required: ["isCorrect", "feedback"],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No validation returned");
    return JSON.parse(text) as EvaluationResponse;
    
  } catch (error) {
    console.error("Error evaluating answer:", error);
    // Fallback in case of error - assume correct to not block, but warn
    return { isCorrect: true, feedback: "Omlouváme se, AI server neodpovídá. Uznáváme ti to." };
  }
};