export enum UserRole {
  STUDENT = 'STUDENT',
  TEACHER = 'TEACHER'
}

export type DifficultyLevel = 'EASY' | 'MEDIUM' | 'HARD';

export type AnswerStatus = 'CORRECT' | 'INCORRECT';

export interface User {
  name: string;
  email: string;
  role: UserRole;
}

export interface DailyContent {
  day: number;
  topic: string; 
  question: string; // The IT question for ZŠ
  fact: string; // Educational explanation
  joke: string; 
  imagePrompt: string; 
}

export interface GeneratedImageResponse {
  imageUrl: string | null;
  error?: string;
}

export interface EvaluationResponse {
  isCorrect: boolean;
  feedback: string;
}